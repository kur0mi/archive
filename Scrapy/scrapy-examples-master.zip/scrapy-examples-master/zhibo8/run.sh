#!/bin/bash

set -x

scrapy crawl zhibo8_schedule 
