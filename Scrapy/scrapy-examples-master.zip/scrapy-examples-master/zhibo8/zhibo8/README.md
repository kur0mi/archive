抓取虎扑新闻和直播吧赛程
基于scrapy[http://scrapy.org/]
